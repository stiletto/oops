#define	C_GRE_MODID	7777
#define	C_GRE_NAME	"gre"

#define TUN_BOUND               0x010
#define TUN_BIND_SENT           0x020
#define TUN_SRC                 0x040
#define TUN_DST                 0x080
#define TUN_FASTPATH            0x200

#define	IPPROTO_GRE		47

typedef	struct	gre_header {
	uint16_t	flag_ver;
	uint16_t	proto_type;
/*	uint16_t	cksum;
	uint16_t	offset;
	uint32_t	key;
	uint32_t	seq;
	uint32_t	routing;*/
} gre_header_t;
